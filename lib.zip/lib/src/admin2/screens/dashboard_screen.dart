import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import '../models/dashboard_models.dart';
import '../providers/dashboard_provider.dart';
import '../widgets/analytics_widgets.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  bool isRealTimeMode = false;
  String selectedTimeRange = '7d';
  String selectedGeographicLevel = 'country';
  String geographicParentCode = '';

  @override
  void initState() {
    super.initState();
    // Load initial data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref
          .read(dashboardNotifierProvider.notifier)
          .loadData(timeRange: selectedTimeRange);
    });
  }

  @override
  Widget build(BuildContext context) {
    final dashboardAsync = ref.watch(dashboardDataProvider);
    final isRealTime = ref.watch(dashboardRealTimeProvider);

    return Scaffold(
      body: dashboardAsync.when(
        loading: () => _buildLoadingState(),
        error: (err, stack) => _buildErrorState(err),
        data: (dashboard) => _buildDashboard(dashboard, isRealTime),
      ),
    );
  }

  Widget _buildLoadingState() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          const SizedBox(height: 32),
          _buildKPISkeleton(),
          const SizedBox(height: 32),
          _buildChartsSkeleton(),
        ],
      ),
    );
  }

  Widget _buildErrorState(Object err) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 64, color: Colors.red),
          const SizedBox(height: 16),
          Text('Failed to load dashboard: $err'),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => ref.refresh(dashboardDataProvider),
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildDashboard(DashboardData dashboard, bool isRealTime) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          const SizedBox(height: 32),
          _buildKPICards(dashboard.kpiMetrics),
          const SizedBox(height: 32),
          _buildUserGrowthChart(dashboard.userGrowthData),
          const SizedBox(height: 32),
          _buildActivityHeatmap(dashboard.hourlyActivity),
          const SizedBox(height: 32),
          _buildGeographicWidget(dashboard.geographicData),
          const SizedBox(height: 32),
          _buildCategoryInsights(dashboard.categoryInsights),
          const SizedBox(height: 32),
          _buildTopPostsTable(dashboard.topPosts),
          const SizedBox(height: 32),
          _buildConversionFunnel(dashboard.conversionFunnel),
          const SizedBox(height: 32),
          _buildExportActions(),
        ],
      ),
    ).animate().fadeIn(duration: 500.ms);
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Dashboard Overview',
              style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Real-time insights into platform performance and user engagement.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.7),
                  ),
            ),
          ],
        ),
        Row(
          children: [
            // Time Range Selector
            Container(
              width: 140,
              child: DropdownButtonFormField<String>(
                value: selectedTimeRange,
                decoration: InputDecoration(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: const [
                  DropdownMenuItem(value: '1d', child: Text('Today')),
                  DropdownMenuItem(value: '7d', child: Text('Last 7 days')),
                  DropdownMenuItem(value: '30d', child: Text('Last 30 days')),
                  DropdownMenuItem(value: 'custom', child: Text('Custom')),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() => selectedTimeRange = value);
                    ref.read(dashboardTimeRangeProvider.notifier).state = value;
                  }
                },
              ),
            ),
            const SizedBox(width: 16),
            // Real-time Toggle
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isRealTimeMode
                    ? Theme.of(context).primaryColor.withOpacity(0.1)
                    : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: isRealTimeMode
                        ? Theme.of(context).primaryColor.withOpacity(0.3)
                        : Theme.of(context).colorScheme.outline),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.circle,
                    size: 12,
                    color: isRealTimeMode
                        ? Theme.of(context).primaryColor
                        : Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withOpacity(0.5),
                  )
                      .animate(onPlay: (controller) => controller.repeat())
                      .scale(
                          begin: const Offset(1, 1),
                          end: const Offset(1.2, 1.2))
                      .then()
                      .scale(
                          begin: const Offset(1.2, 1.2),
                          end: const Offset(1, 1)),
                  const SizedBox(width: 8),
                  Text(
                    'Live Mode',
                    style: TextStyle(
                      color: isRealTimeMode
                          ? Theme.of(context).primaryColor
                          : Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withOpacity(0.7),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Switch(
                    value: isRealTimeMode,
                    onChanged: (value) {
                      setState(() => isRealTimeMode = value);
                      ref.read(dashboardRealTimeProvider.notifier).state =
                          value;
                    },
                    activeColor: Theme.of(context).primaryColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    ).animate().fadeIn(duration: 500.ms).slideY(begin: -0.2, end: 0);
  }

  Widget _buildKPISkeleton() {
    return LayoutBuilder(
      builder: (context, constraints) {
        int columns = constraints.maxWidth > 1200
            ? 6
            : constraints.maxWidth > 800
                ? 3
                : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: columns,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.5,
          children: List.generate(6, (index) => _buildSkeletonCard()),
        );
      },
    );
  }

  Widget _buildSkeletonCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            height: 24,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 60,
            height: 16,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ],
      ),
    )
        .animate(onPlay: (controller) => controller.repeat())
        .shimmer(duration: 1000.ms);
  }

  Widget _buildChartsSkeleton() {
    return LayoutBuilder(
      builder: (context, constraints) {
        bool isMobile = constraints.maxWidth < 768;
        return isMobile
            ? Column(
                children: [
                  _buildSkeletonChart(),
                  const SizedBox(height: 24),
                  _buildSkeletonChart(),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: _buildSkeletonChart()),
                  const SizedBox(width: 24),
                  Expanded(child: _buildSkeletonChart()),
                ],
              );
      },
    );
  }

  Widget _buildSkeletonChart() {
    return Container(
      height: 300,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 200,
                height: 24,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    )
        .animate(onPlay: (controller) => controller.repeat())
        .shimmer(duration: 1000.ms);
  }

  Widget _buildKPICards(KPIMetrics metrics) {
    return LayoutBuilder(
      builder: (context, constraints) {
        int columns = constraints.maxWidth > 1200
            ? 6
            : constraints.maxWidth > 800
                ? 3
                : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: columns,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.5,
          children: [
            MetricCard(
              title: 'Total Members',
              value: metrics.totalMembers.toString(),
              icon: FontAwesomeIcons.crown,
              color: Colors.purple,
              trend: metrics.membersGrowth > 0
                  ? '+${metrics.membersGrowth.toStringAsFixed(1)}%'
                  : '${metrics.membersGrowth.toStringAsFixed(1)}%',
              trendColor:
                  metrics.membersGrowth >= 0 ? Colors.green : Colors.red,
            ),
            MetricCard(
              title: 'Non-Members',
              value: metrics.totalNonMembers.toString(),
              icon: FontAwesomeIcons.users,
              color: Colors.blue,
              trend: metrics.nonMembersGrowth > 0
                  ? '+${metrics.nonMembersGrowth.toStringAsFixed(1)}%'
                  : '${metrics.nonMembersGrowth.toStringAsFixed(1)}%',
              trendColor:
                  metrics.nonMembersGrowth >= 0 ? Colors.green : Colors.red,
            ),
            MetricCard(
              title: 'Daily Active Users',
              value: metrics.dailyActiveUsers.toString(),
              icon: FontAwesomeIcons.userCheck,
              color: Colors.green,
              trend: metrics.dauGrowth > 0
                  ? '+${metrics.dauGrowth.toStringAsFixed(1)}%'
                  : '${metrics.dauGrowth.toStringAsFixed(1)}%',
              trendColor: metrics.dauGrowth >= 0 ? Colors.green : Colors.red,
            ),
            MetricCard(
              title: 'Credits Used Today',
              value: metrics.creditsUsedToday.toString(),
              icon: FontAwesomeIcons.coins,
              color: Colors.amber,
              trend: metrics.creditsGrowth > 0
                  ? '+${metrics.creditsGrowth.toStringAsFixed(1)}%'
                  : '${metrics.creditsGrowth.toStringAsFixed(1)}%',
              trendColor:
                  metrics.creditsGrowth >= 0 ? Colors.green : Colors.red,
            ),
            MetricCard(
              title: 'Total Referrals',
              value: metrics.totalReferrals.toString(),
              icon: FontAwesomeIcons.shareNodes,
              color: Colors.orange,
              trend: metrics.referralsGrowth > 0
                  ? '+${metrics.referralsGrowth.toStringAsFixed(1)}%'
                  : '${metrics.referralsGrowth.toStringAsFixed(1)}%',
              trendColor:
                  metrics.referralsGrowth >= 0 ? Colors.green : Colors.red,
            ),
            MetricCard(
              title: 'Posts Viewed Today',
              value: metrics.postsViewedToday.toString(),
              icon: FontAwesomeIcons.eye,
              color: Colors.teal,
              trend: metrics.viewsGrowth > 0
                  ? '+${metrics.viewsGrowth.toStringAsFixed(1)}%'
                  : '${metrics.viewsGrowth.toStringAsFixed(1)}%',
              trendColor: metrics.viewsGrowth >= 0 ? Colors.green : Colors.red,
            ),
          ],
        );
      },
    ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.2, end: 0);
  }

  Widget _buildUserGrowthChart(List<UserGrowthData> growthData) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'User Growth Trend',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.purple.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: Colors.purple,
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text('Members'),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text('Non-Members'),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 300,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (value) => FlLine(
                    color: Colors.grey.shade200,
                    strokeWidth: 1,
                    dashArray: [5, 5],
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= growthData.length)
                          return const Text('');
                        final date = growthData[value.toInt()].date;
                        return Text(
                          '${date.month}/${date.day}',
                          style: const TextStyle(fontSize: 12),
                        );
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 50,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: const TextStyle(fontSize: 12),
                        );
                      },
                    ),
                  ),
                  topTitles:
                      AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles:
                      AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                borderData: FlBorderData(
                  show: true,
                  border: Border.all(color: Colors.grey.shade300),
                ),
                lineBarsData: [
                  // Members line
                  LineChartBarData(
                    spots: growthData.asMap().entries.map((entry) {
                      return FlSpot(
                          entry.key.toDouble(), entry.value.members.toDouble());
                    }).toList(),
                    isCurved: true,
                    color: Colors.purple,
                    barWidth: 3,
                    belowBarData: BarAreaData(
                      show: true,
                      color: Colors.purple.withOpacity(0.1),
                    ),
                    dotData: FlDotData(show: false),
                  ),
                  // Non-members line
                  LineChartBarData(
                    spots: growthData.asMap().entries.map((entry) {
                      return FlSpot(entry.key.toDouble(),
                          entry.value.nonMembers.toDouble());
                    }).toList(),
                    isCurved: true,
                    color: Colors.blue,
                    barWidth: 3,
                    belowBarData: BarAreaData(
                      show: true,
                      color: Colors.blue.withOpacity(0.1),
                    ),
                    dotData: FlDotData(show: false),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 700.ms).slideY(begin: 0.2, end: 0);
  }

  Widget _buildActivityHeatmap(List<HourlyActivity> hourlyActivity) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).colorScheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Daily Usage Pattern',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Platform activity distribution by hour',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey.shade600,
                ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 200,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: hourlyActivity.isNotEmpty
                    ? hourlyActivity
                            .map((h) => h.activityCount)
                            .reduce((a, b) => a > b ? a : b)
                            .toDouble() *
                        1.2
                    : 100,
                barTouchData: BarTouchData(
                  enabled: true,
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipColor: (_) => Colors.white,
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      final activity = hourlyActivity[groupIndex];
                      return BarTooltipItem(
                        '${activity.hour}:00 - ${activity.activityCount} activities',
                        const TextStyle(color: Colors.black),
                      );
                    },
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= hourlyActivity.length)
                          return const Text('');
                        return Text(
                          '${hourlyActivity[value.toInt()].hour}',
                          style: const TextStyle(fontSize: 12),
                        );
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          '${value.toInt()}',
                          style: const TextStyle(fontSize: 12),
                        );
                      },
                    ),
                  ),
                  topTitles:
                      AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles:
                      AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                borderData: FlBorderData(
                  show: true,
                  border: Border.all(color: Colors.grey.shade300),
                ),
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (value) => FlLine(
                    color: Colors.grey.shade200,
                    strokeWidth: 1,
                    dashArray: [5, 5],
                  ),
                ),
                barGroups: hourlyActivity.asMap().entries.map((entry) {
                  final index = entry.key;
                  final activity = entry.value;

                  return BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: activity.activityCount.toDouble(),
                        color: _getActivityColor(activity.activityCount),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(4),
                          topRight: Radius.circular(4),
                        ),
                      ),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 800.ms).slideY(begin: 0.2, end: 0);
  }

  Color _getActivityColor(int count) {
    if (count > 50) return Colors.green.shade400;
    if (count > 25) return Colors.amber.shade400;
    return Colors.red.shade400;
  }

  Widget _buildGeographicWidget(GeographicData geoData) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).colorScheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Geographic Distribution',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              Row(
                children: [
                  if (geographicParentCode.isNotEmpty)
                    TextButton.icon(
                      onPressed: () {
                        // Navigate back logic
                      },
                      icon: const Icon(Icons.arrow_back),
                      label: const Text('Back'),
                    ),
                  const SizedBox(width: 12),
                  DropdownButton<String>(
                    value: selectedGeographicLevel,
                    items: const [
                      DropdownMenuItem(
                          value: 'country', child: Text('Country')),
                      DropdownMenuItem(value: 'state', child: Text('State')),
                      DropdownMenuItem(value: 'city', child: Text('City')),
                      DropdownMenuItem(
                          value: 'pincode', child: Text('Pincode')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => selectedGeographicLevel = value);
                        ref.read(geographicLevelProvider.notifier).state =
                            value;
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          geoData.items.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(48),
                    child: Text('No geographic data available'),
                  ),
                )
              : GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 2,
                  ),
                  itemCount: geoData.items.length,
                  itemBuilder: (context, index) {
                    final item = geoData.items[index];
                    return InkWell(
                      onTap: () {
                        // Drill down logic
                        setState(() => geographicParentCode = item.code);
                        ref.read(geographicParentProvider.notifier).state =
                            item.code;
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              item.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  '${item.userCount} users',
                                  style: TextStyle(
                                    color: Colors.grey.shade600,
                                    fontSize: 14,
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      '${item.percentage.toStringAsFixed(1)}%',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Icon(
                                      item.isGrowing
                                          ? Icons.trending_up
                                          : Icons.trending_down,
                                      size: 16,
                                      color: item.isGrowing
                                          ? Colors.green
                                          : Colors.red,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            LinearProgressIndicator(
                              value: item.percentage / 100,
                              backgroundColor: Colors.grey.shade200,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                item.isGrowing
                                    ? Colors.green.shade400
                                    : Colors.blue.shade400,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ],
      ),
    ).animate().fadeIn(duration: 900.ms).slideY(begin: 0.2, end: 0);
  }

  Widget _buildCategoryInsights(List<CategoryInsight> categories) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).colorScheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Category Insights',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 24),
          ExpansionPanelList(
            expansionCallback: (int index, bool isExpanded) {
              setState(() {
                categories[index] = categories[index]; // Trigger rebuild
              });
            },
            children: categories.map((category) {
              return ExpansionPanel(
                headerBuilder: (BuildContext context, bool isExpanded) {
                  return ListTile(
                    leading: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: category.color.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.category,
                        color: category.color,
                      ),
                    ),
                    title: Text(
                      category.category,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      '${category.totalPins} pins • ${category.totalImages} images',
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '${category.growthPercentage > 0 ? '+' : ''}${category.growthPercentage.toStringAsFixed(1)}%',
                          style: TextStyle(
                            color: category.growthPercentage >= 0
                                ? Colors.green
                                : Colors.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          category.growthPercentage >= 0
                              ? Icons.trending_up
                              : Icons.trending_down,
                          color: category.growthPercentage >= 0
                              ? Colors.green
                              : Colors.red,
                        ),
                      ],
                    ),
                  );
                },
                body: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // Top posts for this category
                      ...category.topPosts.map((post) {
                        return ListTile(
                          leading: Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.image),
                          ),
                          title: Text(post.title),
                          subtitle: Text(
                              '${post.views} views • ${post.unlocks} unlocks'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.visibility),
                                onPressed: () {},
                              ),
                              IconButton(
                                icon: const Icon(Icons.share),
                                onPressed: () {},
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 1000.ms).slideY(begin: 0.2, end: 0);
  }

  Widget _buildTopPostsTable(List<TopPost> posts) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Top Performing Posts',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              Row(
                children: [
                  DropdownButton<String>(
                    value: 'views',
                    items: const [
                      DropdownMenuItem(
                          value: 'views', child: Text('Sort by Views')),
                      DropdownMenuItem(
                          value: 'unlocks', child: Text('Sort by Unlocks')),
                      DropdownMenuItem(
                          value: 'saves', child: Text('Sort by Saves')),
                      DropdownMenuItem(
                          value: 'shares', child: Text('Sort by Shares')),
                    ],
                    onChanged: (value) {
                      // Sort logic
                    },
                  ),
                  const SizedBox(width: 12),
                  DropdownButton<String>(
                    value: 'today',
                    items: const [
                      DropdownMenuItem(value: 'today', child: Text('Today')),
                      DropdownMenuItem(value: '7d', child: Text('Last 7 days')),
                      DropdownMenuItem(
                          value: '30d', child: Text('Last 30 days')),
                    ],
                    onChanged: (value) {
                      // Filter logic
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor: MaterialStateProperty.all(Colors.grey.shade50),
              columns: const [
                DataColumn(
                    label: Text('Post',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Category',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Views',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Unlocks',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Saves',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Shares',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Date',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                DataColumn(
                    label: Text('Actions',
                        style: TextStyle(fontWeight: FontWeight.w600))),
              ],
              rows: posts.map((post) {
                return DataRow(
                  cells: [
                    DataCell(
                      Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.image),
                          ),
                          const SizedBox(width: 12),
                          SizedBox(
                            width: 200,
                            child: Text(
                              post.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    DataCell(
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          post.category,
                          style: TextStyle(
                            color: Colors.blue.shade700,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    DataCell(Text(post.views.toString())),
                    DataCell(Text(post.unlocks.toString())),
                    DataCell(Text(post.saves.toString())),
                    DataCell(Text(post.shares.toString())),
                    DataCell(Text(
                        '${post.date.month}/${post.date.day}/${post.date.year}')),
                    DataCell(
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.visibility, size: 16),
                            onPressed: () {},
                          ),
                          IconButton(
                            icon: const Icon(Icons.share, size: 16),
                            onPressed: () {},
                          ),
                          IconButton(
                            icon: const Icon(Icons.link, size: 16),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 1100.ms).slideY(begin: 0.2, end: 0);
  }

  Widget _buildConversionFunnel(ConversionFunnel funnel) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Conversion Funnel',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              Row(
                children: [
                  TextButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.list),
                    label: const Text('List View'),
                  ),
                  const SizedBox(width: 8),
                  TextButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.bar_chart),
                    label: const Text('Chart View'),
                  ),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: '7d',
                    items: const [
                      DropdownMenuItem(value: '1d', child: Text('Today')),
                      DropdownMenuItem(value: '7d', child: Text('Last 7 days')),
                      DropdownMenuItem(
                          value: '30d', child: Text('Last 30 days')),
                    ],
                    onChanged: (value) {},
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          ...[
            funnel.signups,
            funnel.firstLogin,
            funnel.creditUse,
            funnel.membership,
          ].asMap().entries.map((entry) {
            final index = entry.key;
            final stage = entry.value;
            final isFirst = index == 0;

            return Container(
              margin: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        stage.name,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                      Row(
                        children: [
                          Text(
                            '${stage.users} users',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade100,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              '${stage.percentage.toStringAsFixed(1)}%',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.blue.shade700,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (!isFirst) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: stage.changeFromPrevious >= 0
                                    ? Colors.green.shade100
                                    : Colors.red.shade100,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                '${stage.changeFromPrevious >= 0 ? '+' : ''}${stage.changeFromPrevious.toStringAsFixed(1)}%',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: stage.changeFromPrevious >= 0
                                      ? Colors.green.shade700
                                      : Colors.red.shade700,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Stack(
                    children: [
                      Container(
                        height: 32,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 1000),
                        height: 32,
                        width: (stage.percentage / 100) *
                            (MediaQuery.of(context).size.width - 200),
                        decoration: BoxDecoration(
                          color: _getFunnelColor(index),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Center(
                          child: Text(
                            '${stage.users} users',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    ).animate().fadeIn(duration: 1200.ms).slideY(begin: 0.2, end: 0);
  }

  Color _getFunnelColor(int index) {
    const colors = [
      Color(0xFF8b5cf6), // Purple
      Color(0xFF06b6d4), // Cyan
      Color(0xFF10b981), // Green
      Color(0xFFf59e0b), // Amber
    ];
    return colors[index % colors.length];
  }

  Widget _buildExportActions() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Export Dashboard',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Download dashboard data in various formats',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey.shade600,
                ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: () => _exportData('csv'),
                icon: const Icon(Icons.file_download),
                label: const Text('CSV'),
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () => _exportData('pdf'),
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('PDF'),
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () => _exportData('png'),
                icon: const Icon(Icons.image),
                label: const Text('PNG'),
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(duration: 1300.ms).slideY(begin: 0.2, end: 0);
  }

  void _exportData(String format) {
    // Export logic - simplified for now
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Exporting as $format...')),
    );
  }
}
