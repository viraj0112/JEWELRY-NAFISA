import "package:flutter/material.dart";
import "../screens/productupload_screen.dart";
import "package:provider/provider.dart";
import "../sections/users_section.dart";
import "../sections/analytics_section.dart";
import "../sections/content_section.dart";
import "../sections/reports_section.dart";
import "../sections/activity_logs_section.dart";
import "../screens/b2b_creators_screen.dart";
import "../screens/dashboard_screen.dart";
import "../widgets/app_sidebar.dart";
import "../providers/app_state.dart";
import "../providers/users_provider.dart";
import "../widgets/admin_profile_menu.dart";
import "../../providers/theme_provider.dart";

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  Widget _renderContent(String activeView) {
    switch (activeView) {
      case "content":
        return const ContentSection();
      case "users":
        return ChangeNotifierProvider(
          create: (_) => UsersProvider(),
          child: const UsersSection(),
        );
      case "b2b-creators":
        return const B2BCreatorsScreen();
      case "product-upload":
        return const ProductUploadScreen();
      case "analytics":
        return const AnalyticsSection();
      case "reports":
        return const ReportsSection();
      case "activity-logs":
        return const ActivityLogsSection();
      case "dashboard":
        return const DashboardScreen();
      default:
        return const B2BCreatorsScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isMobile = width < 800;
    final isTablet = width >= 800 && width < 1200;

    return Consumer<AppState>(
      builder: (context, appState, child) {
        return Scaffold(
          drawer: isMobile
              ? const Drawer(
                  child: AppSidebar(),
                )
              : null,
          body: Row(
            children: [
              if (!isMobile) const AppSidebar(),
              Expanded(
                child: Container(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: Column(
                    children: [
                      Container(
                        height: 64,
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surface,
                          border: Border(bottom: BorderSide(color: Theme.of(context).colorScheme.outline.withOpacity(0.2))),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            if (isMobile)
                              IconButton(
                                icon: Icon(Icons.menu, color: Theme.of(context).colorScheme.onSurface),
                                onPressed: () => Scaffold.of(context).openDrawer(),
                              )
                            else
                              Text(
                                _getViewTitle(appState.activeView),
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.onSurface
                                ),
                              ),

                            Row(
                              children: [
                                Consumer<ThemeProvider>(
                                  builder: (context, themeProvider, child) {
                                    return IconButton(
                                      icon: Icon(
                                        themeProvider.themeMode == ThemeMode.dark
                                            ? Icons.light_mode
                                            : Icons.dark_mode,
                                        color: Theme.of(context).colorScheme.onSurface,
                                      ),
                                      onPressed: () => themeProvider.toggleTheme(),
                                      tooltip: 'Toggle theme',
                                    );
                                  },
                                ),
                                const AdminProfileMenu(),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.all(isMobile
                              ? 16.0
                              : isTablet
                                  ? 20.0
                                  : 24.0),
                          child: _renderContent(appState.activeView),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _getViewTitle(String view) {
    switch (view) {
      case 'users': return 'Users Management';
      case 'content': return 'Content Management';
      case 'b2b-creators': return 'B2B Creators';
      case 'analytics': return 'Analytics';
      case 'reports': return 'Reports';
      case 'activity-logs': return 'Activity Logs';
      case 'dashboard': return 'Dashboard';
      default: return 'Admin Panel';
    }
  }
}